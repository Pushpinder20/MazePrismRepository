﻿using System.Windows;

namespace Maze.UI
{
        public partial class Shell : Window
    {
        public Shell()
        {
            InitializeComponent();
        }
    }
}
