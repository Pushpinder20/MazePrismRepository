﻿using Maze.Modules.View;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;

namespace Maze.Modules
{
    public class MazeModule : IModule
    {
        private readonly IRegionManager _regionManager;

        public MazeModule(RegionManager regionManager)
        {
            this._regionManager = regionManager;
        }

        public void Initialize()
        {
            _regionManager.Regions["MazeDataRegion"].Add(new MazeView());
        }
    }
}
