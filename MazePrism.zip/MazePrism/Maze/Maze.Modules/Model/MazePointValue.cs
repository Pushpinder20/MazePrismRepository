﻿namespace Maze.Modules.Model
{
    public class MazePointValue
    {
        public MazePointValue()
        {
        }

        public MazePointValue(MazePoint point, string value)
        {
            pointValue = value;
            mazePoint = point;
        }

        public MazePoint mazePoint { get; set; }

        public string pointValue { get; set; }
    }
}
