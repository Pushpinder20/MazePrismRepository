﻿using Maze.Modules.Model;
using System.Data;

namespace Maze.Modules.ViewModel
{
    public interface IMazeViewModel
    {
        void DrawMaze();

        string _maze { get; set; }

        MazePointValue GetStartorFinish(string value);

        DataTable MazeTable
        {
            get;
            set;
        }

        string GetValue(int rowIndex, int columnIndex);
    }
}
