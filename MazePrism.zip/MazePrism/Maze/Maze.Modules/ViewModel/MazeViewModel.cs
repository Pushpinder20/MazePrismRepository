﻿using Maze.Modules.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data;

namespace Maze.Modules.ViewModel
{
    public class MazeViewModel : IMazeViewModel
    {
        private IMazeViewModel model;
        public DataTable mazeTable;
        private const string start = "S";
        private const string finish = "F";
        private const string space = " ";
        private const string traversedPath = ".";
        private const string finalPath = "*";

        #region Constructors
        public MazeViewModel()
        {
            _maze = 
@"
XXXX      
XXXX XXXX 
XX  S   XX
XX X XX XX
X  X   XXX
X X  X   X
X X XXXX X
XXX XXXX X
XXX XXX  X
XXXFXXXXXX";
            DrawMaze();
            TraverseMaze();
        }

        public MazeViewModel(IMazeViewModel obj)
        {
            model = obj;
            _maze = obj._maze;
            MazeTable = obj.MazeTable;
        }
        #endregion


        public string _maze { get; set; }
        public DataTable MazeTable
        {
            get { return mazeTable; }
            set
            {
                mazeTable = value;
            }
        }

        public void DrawMaze()
        {
            string[] lines = _maze.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            MazeTable = new DataTable();
            string line = lines[0];
            try
            {
                for (int i = 0; i < line.Length; i++)
                    MazeTable.Columns.Add();

                for (int i = 0; i < lines.Length; i++)
                {
                    DataRow dataRow = MazeTable.NewRow();
                    string currentLine = lines[i];
                    for (int j = 0; j < currentLine.Length; j++)
                    {
                        dataRow[j] = currentLine[j];
                    }
                    MazeTable.Rows.Add(dataRow);
                }
            }

            catch (Exception e)
            {
                throw e;
            }
        }

        public void TraverseMaze()
        {
            try
            {
                MazePointValue startingPoint = GetStartorFinish(start);
                MazePointValue finishingPoint = GetStartorFinish(finish);
                List<MazePointValue> traversedPoints = new List<MazePointValue>();
                traversedPoints.Add(startingPoint);
                List<MazePointValue> adjacentPoints = GetAdjacentPoints(startingPoint.mazePoint.row, startingPoint.mazePoint.column);
                MazePointValue selectedPoint = adjacentPoints.Where(x => x.pointValue.Equals(space)).First();
                string isFinished = selectedPoint.pointValue;

                if (isFinished != finish)
                {
                    do
                    {
                        string cellValue = GetValue(selectedPoint.mazePoint.row, selectedPoint.mazePoint.column);
                        //check if the path can be traversed, and replace " " with "*"
                        if (cellValue == space)
                        {
                            UpdateValue(selectedPoint.mazePoint.row, selectedPoint.mazePoint.column, finalPath);
                        }

                        //add the traversed point to the list of traversed points
                        if (!traversedPoints.Any(x => x.mazePoint.row == selectedPoint.mazePoint.row && x.mazePoint.column == selectedPoint.mazePoint.column))
                        {
                            traversedPoints.Add(selectedPoint);
                        }

                        //find the new adjacent points for the selected point
                        adjacentPoints = GetAdjacentPoints(selectedPoint.mazePoint.row, selectedPoint.mazePoint.column);
                        adjacentPoints = adjacentPoints.Where(x => !traversedPoints.Any(y => y.mazePoint.column == x.mazePoint.column && y.mazePoint.row == x.mazePoint.row)).ToList();

                        //if no more adjacent points to traverse, set to starting point
                        if (adjacentPoints.Where(x => x.pointValue.Equals(space)).Count() > 1)
                        {
                            startingPoint = selectedPoint;
                        }

                        selectedPoint = GetSelectedPoint(adjacentPoints, traversedPoints, startingPoint);

                        isFinished = selectedPoint.pointValue;
                    }
                    while (isFinished != finish);
                }
            }


            catch (Exception e)
            {
                throw e;
            }

        }

        public List<MazePointValue> GetAdjacentPoints(int row, int column)
        {
            List<MazePointValue> points = new List<MazePointValue>();
            try
            {
                if (column > 0)
                {
                    MazePoint leftPoint = new MazePoint(row, column - 1);
                    string value = GetValue(row, column - 1);
                    points.Add(new MazePointValue(leftPoint, value));
                }

                if (column < MazeTable.Columns.Count - 1)
                {
                    MazePoint rightPoint = new MazePoint(row, column + 1);
                    string value = GetValue(row, column + 1);
                    points.Add(new MazePointValue(rightPoint, value));
                }

                if (row > 0)
                {
                    MazePoint topPoint = new MazePoint(row - 1, column);
                    string value = GetValue(row - 1, column);
                    points.Add(new MazePointValue(topPoint, value));
                }

                if (row < MazeTable.Rows.Count - 1)
                {
                    MazePoint bottomPoint = new MazePoint(row + 1, column);
                    string value = GetValue(row + 1, column);
                    points.Add(new MazePointValue(bottomPoint, value));
                }
            }

            catch (Exception e)
            {
                throw e;
            }

            return points;
        }

        public MazePointValue GetSelectedPoint(List<MazePointValue> adjacentPoints, List<MazePointValue> traversedPoints, MazePointValue startingPoint)
        {
            MazePointValue selectedPoint = new MazePointValue();
            try
            {
                if (adjacentPoints.Any(x => x.pointValue.Equals(finish)))
                    selectedPoint = adjacentPoints.Where(x => x.pointValue.Equals(finish)).First();
                else if (adjacentPoints.Any(x => x.pointValue.Equals(space)))
                    selectedPoint = adjacentPoints.Where(x => x.pointValue.Equals(space)).First();
                else
                {
                    selectedPoint = startingPoint;
                    int startingPointIndex = traversedPoints.IndexOf(startingPoint);
                    for (int i = traversedPoints.Count - 1; i > -1; i--)
                    {
                        if (i == startingPointIndex)
                            break;
                        UpdateValue(traversedPoints[i].mazePoint.row, traversedPoints[i].mazePoint.column, traversedPath);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return selectedPoint;
        }

        public MazePointValue GetStartorFinish(string value)
        {
            try
            {
                for (int i = 0; i < MazeTable.Rows.Count; i++)
                {
                    DataRow row = MazeTable.Rows[i];
                    for (int j = 0; j < MazeTable.Columns.Count; j++)
                    {
                        if (row[j].ToString().Equals(value, StringComparison.InvariantCulture))
                            return new MazePointValue(new MazePoint(i, j), row[j].ToString());
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return new MazePointValue();
        }

        public string GetValue(int rowIndex, int columnIndex)
        {
            DataRow row = MazeTable.Rows[rowIndex];
            string value = row[columnIndex].ToString();
            return value;
        }

        public void UpdateValue(int rowIndex, int columnIndex, string value)
        {
            DataRow row = MazeTable.Rows[rowIndex];
            row[columnIndex] = value;
        }
    }
}
