﻿using Maze.Modules.ViewModel;
using Microsoft.Practices.Prism.Events;
using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace Maze.Modules.View
{
    public partial class MazeView : UserControl
    {
        private MazeViewModel mazeViewModel = null;
        public MazeView()
        {
            InitializeComponent();
            mazeViewModel = new MazeViewModel();
            DataContext = mazeViewModel;
        }
    }
}
