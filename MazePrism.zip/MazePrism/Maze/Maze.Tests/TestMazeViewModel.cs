﻿using Maze.Modules.Model;
using Maze.Modules.ViewModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Data;

namespace Maze.Tests
{
    [TestClass]
    public class TestMazeViewModel
    {
        public const string maze =
@"XXXXX
XXS X
XXX X
X   X
XFXXX";
        DataTable testTable = new DataTable();
        Mock<IMazeViewModel> mockViewModel = new Mock<IMazeViewModel>();
        Mock<MazePoint> mazePoint = new Mock<MazePoint>();
        Mock<MazePointValue> mazePointValue = new Mock<MazePointValue>();
        string[] lines = maze.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

        [TestInitialize]
        public void Initialize()
        {
            mockViewModel.SetupGet(s => s._maze).Returns(maze);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            viewModel.DrawMaze();
            testTable = viewModel.MazeTable;
        }

        [TestMethod]
        public void TestDrawMaze()
        {
            mockViewModel.SetupGet(s => s._maze).Returns(maze);
            mockViewModel.SetupGet(s => s.MazeTable).Returns(testTable);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            viewModel.DrawMaze();
            mockViewModel.VerifyAll();
        }

        [TestMethod]
        public void TestTraverseMaze()
        {
            mockViewModel.SetupGet(s => s._maze).Returns(maze);
            mockViewModel.SetupGet(s => s.MazeTable).Returns(testTable);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            viewModel.TraverseMaze();
            mockViewModel.VerifyAll();
        }

        [TestMethod]
        public void TestGetStartorFinishAreEqual()
        {
            MazePointValue expectedValue = new MazePointValue(new MazePoint(1, 2), "S");
            mockViewModel.SetupGet(s => s.MazeTable).Returns(testTable);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            MazePointValue actualValue = viewModel.GetStartorFinish("S");
            Assert.AreEqual(expectedValue.mazePoint.row, actualValue.mazePoint.row);
            Assert.AreEqual(expectedValue.mazePoint.column, actualValue.mazePoint.column);
            Assert.AreEqual(expectedValue.pointValue, actualValue.pointValue);
        }

        [TestMethod]
        public void TestGetStartingPointAreNotEqual()
        {
            MazePointValue expectedValue = new MazePointValue(new MazePoint(0, 0), "Z");
            mockViewModel.SetupGet(s => s.MazeTable).Returns(testTable);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            MazePointValue actualValue = viewModel.GetStartorFinish("S");
            Assert.AreNotEqual(expectedValue.mazePoint.row, actualValue.mazePoint.row);
            Assert.AreNotEqual(expectedValue.mazePoint.column, actualValue.mazePoint.column);
            Assert.AreNotEqual(expectedValue.pointValue, actualValue.pointValue);
        }

        [TestMethod]
        public void TestGetValue()
        {
            string expectedValue = "F";
            mockViewModel.SetupGet(s => s.MazeTable).Returns(testTable);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            string actualValue = viewModel.GetValue(4, 1);
            Assert.AreEqual(expectedValue, actualValue);
        }

        [TestMethod]
        public void TestGetAdjacentPoints()
        {
            List<MazePointValue> expectedPoints = new List<MazePointValue>();
            expectedPoints.Add(new MazePointValue() { mazePoint = new MazePoint(2, 1), pointValue = "X" });
            expectedPoints.Add(new MazePointValue() { mazePoint = new MazePoint(2, 3), pointValue = " " });
            expectedPoints.Add(new MazePointValue() { mazePoint = new MazePoint(1, 2), pointValue = "S" });
            expectedPoints.Add(new MazePointValue() { mazePoint = new MazePoint(3, 2), pointValue = " " });
            mockViewModel.SetupSequence(s => s.GetValue(It.IsAny<int>(), It.IsAny<int>())).Returns("X").Returns(" ").Returns("S").Returns(" ");
            mockViewModel.SetupGet(s => s.MazeTable).Returns(testTable);
            MazeViewModel viewModel = new MazeViewModel(mockViewModel.Object);
            List<MazePointValue> actualValues = viewModel.GetAdjacentPoints(2, 2);
            for (int i = 0; i < actualValues.Count; i++)
            {
                Assert.AreEqual(expectedPoints[i].mazePoint.row, actualValues[i].mazePoint.row);
                Assert.AreEqual(expectedPoints[i].mazePoint.column, actualValues[i].mazePoint.column);
                Assert.AreEqual(expectedPoints[i].pointValue, actualValues[i].pointValue);
            }
        }
    }
}

