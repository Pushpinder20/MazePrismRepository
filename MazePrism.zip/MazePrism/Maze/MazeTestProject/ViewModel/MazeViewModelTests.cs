﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MazeTestProject.Tests
{
    [TestClass()]
    public class MazeViewModelTests
    {
        [TestMethod()]
        public void MazeViewModelTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void MazeFunctionsTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void DrawMazeTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void TraverseMazeTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetAdjacentPointsTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetStartingPointTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetFinishingPointTest()
        {
            Assert.Fail();
        }
    }
}